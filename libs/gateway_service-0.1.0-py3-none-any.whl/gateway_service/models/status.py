class TaskStatus:
    new: int = 1
    pvt_calculated: int = 2
    ipr_calculated: int = 3
    vlp_calculated: int = 4
    processed: int = 5
    error: int = 6
